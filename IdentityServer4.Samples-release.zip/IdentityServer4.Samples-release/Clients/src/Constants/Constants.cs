﻿namespace Clients
{
    public class Constants
    {
        public const string Authority = "http://localhost:5000";
        public const string SampleApi = "http://localhost:3721/";
    }
}