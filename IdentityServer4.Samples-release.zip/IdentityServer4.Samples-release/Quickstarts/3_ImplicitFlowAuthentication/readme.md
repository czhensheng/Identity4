# Quickstart #3: User Authentication using OpenID Connect Implicit Flow

This quickstart adds support for interactive user authentication using the OpenID Connect implicit flow.

## Tutorial

The tutorial that goes along with this sample can be found here [Adding User Authentication with OpenID Connect](http://docs.identityserver.io/en/release/quickstarts/3_interactive_login.html)
